##
# \file
#

import qbruntime.qbruntime as _cQbRuntime

__all__ = [
    "__version__",
    "__git_version__",
    "__vendor__",
    "__product__",
]

##
# \addtogroup PythonAPI
# @{

__version__: str = _cQbRuntime.version.__version__
__git_version__: str = _cQbRuntime.version.__git_version__
__vendor__: str = _cQbRuntime.version.__vendor__
__product__: str = _cQbRuntime.version.__product__

##
# @}
